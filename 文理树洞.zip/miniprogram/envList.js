const envList = [{"envId":"cloud1-0g4zowql9d5907c4","alias":"cloud1"}]
const isMac = false
module.exports = {
    envList,
    isMac
}